This is a repackaged version of [https://github.com/pybox2d/pybox2d](pybox2d). For all information, see that repo. For licensing information, see `LICENSE`.
